
import { Component } from '@angular/core';
@Component({selector:'app-new-match', templateUrl:'./new-match.component.html'})
export class NewMatchComponent { teamA=''; teamB=''; overs=20; }
