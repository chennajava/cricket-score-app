
import { Component } from '@angular/core';
@Component({selector:'app-history', template:'<p>History</p>'})
export class HistoryComponent {}
