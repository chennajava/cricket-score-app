
import { Component } from '@angular/core';
@Component({selector:'app-scoring', templateUrl:'./scoring.component.html'})
export class ScoringComponent { runs=0; balls=0; addRun(r:number){this.runs+=r; this.balls++;}}
