
@Component({selector:'scoring',templateUrl:'scoring.component.html'})
export class ScoringComponent {
 runs=0; balls=0; wickets=0;
 addRun(r:number){this.runs+=r; this.balls++;}
 addWicket(){this.wickets++; this.balls++;}
}
