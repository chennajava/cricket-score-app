
@Component({selector:'history',template:'<p>History</p>'})
export class HistoryComponent {}
