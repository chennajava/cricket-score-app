
@Component({selector:'new-match',templateUrl:'new-match.component.html'})
export class NewMatchComponent {
 teamA=''; teamB=''; overs=20;
}
