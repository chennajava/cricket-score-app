
export interface Innings {
  runs:number; wickets:number; overs:number; balls:number;
}
export interface Match {
  teamA:string; teamB:string; totalOvers:number;
  innings1:Innings; innings2?:Innings; status:string;
}
