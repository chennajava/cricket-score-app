
@Injectable({providedIn:'root'})
export class MatchService {
  match:any;
  save(){ localStorage.setItem('match',JSON.stringify(this.match)); }
  load(){ return JSON.parse(localStorage.getItem('match')!); }
}
